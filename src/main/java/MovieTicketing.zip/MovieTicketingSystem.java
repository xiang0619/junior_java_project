import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class MovieTicketingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean validCreditCard = false;
        boolean validCVV = false;
        int rejectCount = 0;

        System.out.print("Enter username: ");
        String username = scanner.next();
        System.out.print("Enter password: ");
        String password = scanner.next();

        if (isValidUser(username, password)) {
            System.out.println("Welcome, " + username + "!");

            System.out.print("Do you want to be a member? (Y/N): ");
            String memberChoice = scanner.next();

            if (memberChoice.equalsIgnoreCase("Y")) {
                System.out.print("Enter credit card number: ");
                String creditCardNumber = scanner.next();
                System.out.print("Enter CVV: ");
                String cvv = scanner.next();

                validCreditCard = isValidCreditCardNumber(creditCardNumber);
                validCVV = isValidCVV(cvv);

                if (validCreditCard && validCVV) {
                    System.out.println("-RM" + memberFee);
                    System.out.println("Congratulations! You are now a member.");
                } else {
                    System.out.println("Invalid credit card number or CVV. Please try again.");
                }
            } else if (memberChoice.equalsIgnoreCase("N")) {
                validCreditCard = true;
                validCVV = true;
            } else {
                System.out.println("Invalid input. Please try again.");
            }

            System.out.println("Movie options:");
            ArrayList<Movie> movies = new ArrayList<>();
            movies.add(new Movie("1", "Avengers 3", "Action", new Date(121, 0, 1), 150));
            movies.add(new Movie("2", "Avatar 2", "Sci-Fi", new Date(121, 0, 1), 180));
            movies.add(new Movie("3", "Gran Turismo", "Racing", new Date(121, 9, 30), 100));

            while (true) {
                for (Movie movie : movies) {
                    System.out.println(movie.getMovieID() + ". " + movie.getMovieName());
                }

                System.out.print("Enter the movie ID you are interested in: ");
                String movieID = scanner.next();

                Movie selectedMovie = null;
                for (Movie movie : movies) {
                    if (movie.getMovieID().equals(movieID)) {
                        selectedMovie = movie;
                        break;
                    }
                }

                if (selectedMovie != null) {
                    System.out.println("Selected movie: " + selectedMovie.getMovieName());
                    System.out.println("Genre: " + selectedMovie.getMovieType());
                    System.out.println("Release Date: " + selectedMovie.getReleaseDate());
                    System.out.println("Duration: " + selectedMovie.getDuration() + " minutes");

                    System.out.print("Do you want to continue with this movie? (Y/N): ");
                    String continueChoice = scanner.next();

                    if (continueChoice.equalsIgnoreCase("Y")) {
                        Schedule schedule = new Schedule();
                        schedule.setStartTime(new Date(123, 8, 20, 10, 0)); // Random start time
                        schedule.setEndTime(new Date(123, 8, 20, 12, 0)); // Random end time

                        String scheduleDetails = schedule.viewSchedule();
                        System.out.println(scheduleDetails);
                        rejectCount = 0; // Reset the rejection count
                    } else if (continueChoice.equalsIgnoreCase("N")) {
                        rejectCount++; // Increment the rejection count

                        if (rejectCount == 2) {
                            System.out.println("Thank you for using the Movie Ticketing System. Goodbye!");
                            break; // End the loop if the user rejects twice in a row
                        } else {
                            System.out.println("Movie options:");
                        }
                    } else {
                        System.out.println("Invalid input. Please try again.");
                    }
                } else {
                    System.out.println("Invalid movie ID. Please try again.");
                }
            }
        } else {
            System.out.println("Invalid username or password. Please try again.");
        }
    }

    private static boolean isValidUser(String username, String password) {
        return username.equals("Admin123") && password.equals("password123");
    }

    private static boolean isValidCreditCardNumber(String creditCardNumber) {
        return creditCardNumber.length() == 16 && hasMultipleDifferentDigits(creditCardNumber, 5);
    }

    private static boolean isValidCVV(String cvv) {
        return cvv.length() == 3 && hasMultipleDifferentDigits(cvv, 2);
    }

    private static boolean hasMultipleDifferentDigits(String input, int minDifferentDigits) {
        int count = 0;
        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);
            if (input.indexOf(currentChar) == i) {
                count++;
            }
        }
        return count >= minDifferentDigits;
    }
}

