public class Payment {
    private String paymentID;
    private double totalAmount;
    private boolean paymentStatus;

    public void confirmTransaction() {
        // Implementation to confirm the payment transaction
    }

    public void returnMoneyOnCancellation() {
        // Implementation to return money on cancellation
    }

    public double getTotalAmount() {
        // Implementation to get the total amount
        return totalAmount;
    }

    public String getPaymentID() {
        // Implementation to get the payment ID
        return paymentID;
    }
}
