    public class Seat {
    private String seatID;
    private double price;
    private boolean seatStatus;

    public String getSeatID() {
        return seatID;
    }

    public void setSeatID(String seatID) {
        this.seatID = seatID;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isSeatStatus() {
        return seatStatus;
    }

    public void setSeatStatus(boolean seatStatus) {
        this.seatStatus = seatStatus;
    }

    public String getSeatDetails() {
        return "Seat ID: " + seatID + ", Price: " + price + ", Status: " + (seatStatus ? "Available" : "Occupied");
    }

    public static void displaySeats() {
        char row = 'A';
        for (int i = 1; i <= 7; i++) {
            for (int j = 1; j <= 20; j++) {
                System.out.print(row + String.format("%02d", j) + " ");
                if (j % 10 == 0) {
                    System.out.println();
                }
            }
            row++;
        }
    }
}
