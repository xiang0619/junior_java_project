import java.util.ArrayList;

public class User {

    private boolean isMember; 
    private String customerID;
    String username;
    String password;
    private String phoneNumber;
    private String customerName;
    private char gender;

 

    public boolean login(String username, String password) {
        // Implementation to validate login credentials
        return false;
    }

    public void logout() {
        // Implementation to logout the user
    }

    public String getUsername() {
        // Implementation to get the username
        return username;
    }

    public boolean resetPassword(String password, String confirmPassword) {
        // Implementation to reset the password
        return false;
    }

    public ArrayList<Movie> viewMovies() {
        // Implementation to view available movies
        return new ArrayList<Movie>();
    }

    public boolean bookTicket(Ticket ticket) {
        // Implementation to book a ticket
        return false;
    }

    public boolean cancelBooking() {
        // Implementation to cancel a booking
        return false;
    }

public void setMember(boolean isMember) {
    this.isMember = isMember;
}
}

