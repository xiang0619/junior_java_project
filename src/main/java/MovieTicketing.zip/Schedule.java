import java.time.LocalDateTime;

public class Schedule extends Hall {
    private LocalDateTime startTime;
    private LocalDateTime endTime;

    public String viewSchedule() {
        // Implementation to view schedule details
        // Assuming you have the schedule details stored in the startTime and endTime variables
        return "Schedule details: " + startTime + " - " + endTime;
    }
}
