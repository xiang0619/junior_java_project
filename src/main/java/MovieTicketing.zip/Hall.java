import java.util.ArrayList;

public class Hall extends Seat {
    private String hallID;
    private int capacity;
    private ArrayList<Seat> seats;

    public String getHall() {
        // Implementation to get the hall details
        return "Hall details";
    }

    public int getCapacity() {
        // Implementation to get the hall capacity
        return capacity;
    }

    public ArrayList<Seat> getSeats() {
        // Implementation to get the available seats
        return seats;
    }
}
