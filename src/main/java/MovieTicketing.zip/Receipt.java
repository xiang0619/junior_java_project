import java.time.LocalDateTime;

public class Receipt extends Payment {
    private String receiptID;
    private LocalDateTime receiptDateCreated;

    public String getReceipt() {
        // Implementation to generate the receipt
        return "Receipt details";
    }
}
