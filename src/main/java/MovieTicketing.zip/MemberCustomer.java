public class MemberCustomer extends User {

    private double memberDiscount;
}
