import java.time.LocalDateTime;

public class Booking extends User {

    
    private String bookingID;
    private LocalDateTime bookingDate;
    private Payment payment;
    private Ticket ticket;
    private User user;

    public String bookingDetails() {
        // Implementation to get booking details
        return "Booking details";
    }

    public void processPayment() {
        // Implementation to process the payment
    }
}
