import java.util.ArrayList;
import java.util.Date;

    public class Movie {
        private String movieID;
        private String movieName;
        private String movieType;
        private Date releaseDate;
        private int duration;

    public Movie(String movieID, String movieName, String movieType, Date releaseDate, int duration) {
        this.movieID = movieID;
        this.movieName = movieName;
        this.movieType = movieType;
        this.releaseDate = releaseDate;
        this.duration = duration;
    }

    public String getMovieID() {
        return movieID;
    }

    public String getMovieName() {
        return movieName;
    }

    public String getMovieType() {
        return movieType;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public int getDuration() {
        return duration;
    }
}
